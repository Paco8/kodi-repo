#!/usr/bin/env python
# -*- coding: utf-8 -*-
from resources.lib.startup import EntryPoint

EntryPoint()
