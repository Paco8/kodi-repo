#  Internal libraries and external modified and internally maintained libraries
