#!/usr/bin/env python
# -*- coding: utf-8 -*-

import json
import xbmc

def get_kodi_setting(setting):
    rpc = {'jsonrpc': '2.0',
            'method': 'Settings.GetSettingValue',
            'params': {'setting': setting}, 
            'id': 1}
    json_result = json.loads(xbmc.executeJSONRPC(json.dumps(rpc)))
    if 'result' in json_result and 'value' in json_result['result']:
        return json_result['result']['value']
    else:
        return ''

def get_preferred_subtitle_language():
    return get_kodi_setting('locale.subtitlelanguage')
    
def get_locale_country():
    return get_kodi_setting('locale.country')

def check_language_ids(tracks):
    available_es_la = False
    for track in tracks:
        if (track['language'] == 'es'):
            available_es_la = True;
            break;

    if not available_es_la:
        for track in tracks:
            if (track['language'] == 'es-ES'): track['language'] = 'es'
