# -*- coding: utf-8 -*-
"""Kodi GUI stuff"""
# pylint: disable=wildcard-import
from __future__ import absolute_import, division, unicode_literals

from .dialogs import *  # pylint: disable=redefined-builtin
from .xmldialogs import *
