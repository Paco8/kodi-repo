from slyguy.language import BaseLanguage

class Language(BaseLanguage):
    NEWS_HEADING      = 30001

_ = Language()