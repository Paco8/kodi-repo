from slyguy.settings import CommonSettings
from slyguy.settings.types import Bool,Action
from xbmcaddon import Addon

from .language import _


class Settings(CommonSettings):
    SYNC_WATCHLIST = Bool('sync_watchlist', _.SYNC_WATCHLIST, default=True)
    ENABLE_CHAPTERS = Bool('enable_chapters', default=False)
    USE_TTML2SSA = Bool('use_ttml2ssa', default=True, label=Addon('script.module.ttml2ssa').getLocalizedString(32202))
    SSA_SETTINGS = Action("Addon.OpenSettings(script.module.ttml2ssa)", label=Addon('script.module.ttml2ssa').getLocalizedString(32201))


settings = Settings()
