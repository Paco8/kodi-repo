#!/usr/bin/env python
# -*- coding: utf-8 -*-

import json
import re
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor, as_completed
from copy import deepcopy
from urllib.parse import quote_plus, unquote_plus, quote

import xbmc, xbmcplugin, xbmcgui

from .singleton import Singleton
from .common import key_exists, return_item, return_value, sleep, findKey, MechanizeLogin, decode_token, get_key
from .network import getURL, getURLData, FQify, GrabJSON, GrabJSONParallel, LocaleSelector
from .db import init_dbs, SQLiteVideoData
from .logging import Log
from .itemlisting import setContentAndView, addVideo, addDir
from .users import loadUsers, loadUser, saveUserCookies, switchUser
from .configs import getConfig, writeConfig
from .export import SetupLibrary
from .l10n import getString, datetimeParser


class PrimeVideo(Singleton):
    """ Wrangler of all things PrimeVideo.com """

    _catalog = {}  # Catalog cache
    _videodata = {'urn2gti': {}}  # Video data cache
    _menuDb = None
    _videoDb = None
    _dbLock = None
    _separator = '/'  # Virtual path separator

    def __init__(self, globalsInstance, settingsInstance):
        self._g = globalsInstance
        self._s = settingsInstance
        self._dateParserData = deepcopy(datetimeParser)
        self._TextCleanPatterns = [[r'\s+-\s*([^&])', r' – \1'],  # Convert dash from small to medium where needed
                                   [r'\s*-\s+([^&])', r' – \1'],  # Convert dash from small to medium where needed
                                   [r'^\s+', ''],  # Remove leading spaces
                                   [r'\s+$', ''],  # Remove trailing spaces
                                   [r' {2,}', ' '],  # Remove double spacing
                                   [r'\.\.\.', '…']]  # Replace triple dots with ellipsis
        # rex compilation
        self._imageRefiner = re.compile(r'\._.*_\.')
        self._reURN = re.compile(r'(?:/gp/video)?/d(?:p|etail)/([^/?]+)(?:/|\?)')
        self._dateParserData['generic'] = re.compile(self._dateParserData['generic'], re.UNICODE)
        self._dateParserData['asianMonthExtractor'] = re.compile(self._dateParserData['asianMonthExtractor'])
        for k in self._dateParserData:
            try:
                self._dateParserData[k]['deconstruct'] = re.compile(self._dateParserData[k]['deconstruct'])
            except: pass
        for i, s in enumerate(self._TextCleanPatterns):
            self._TextCleanPatterns[i][0] = re.compile(s[0])

        self._home_path = getConfig('home', 'root')
        self._LoadCache()

    def _Flush(self, bFlushCacheData=True, bFlushVideoData=False):
        """ Cache catalog and video data into central SQLite databases """
        if self._menuDb is None or self._videoDb is None:
            self._LoadCache()

        if bFlushCacheData and self._catalog:
            now = int(time.time())
            exp = int(self._catalog.get('expiration', now + self._s.catalogCacheExpiry))
            try:
                cat_json = json.dumps(self._catalog, separators=(',', ':'))
                with self._dbLock:
                    with self._menuDb:
                        self._menuDb.execute(
                            'INSERT OR REPLACE INTO menu_cache (market_id, expiration, catalog_json, updated_at) VALUES (?, ?, ?, ?)',
                            (self._g.MarketID, exp, cat_json, now)
                        )
            except Exception as exc:
                Log(f'Failed to flush catalog to menuCache.db: {exc}', Log.ERROR)

        if bFlushVideoData:
            try:
                if isinstance(self._videodata, SQLiteVideoData):
                    self._videodata.flush()
            except Exception as exc:
                Log(f'Failed to flush videodata to videoCache.db: {exc}', Log.ERROR)

    def _LoadCache(self):
        """ Load cached catalog and video data from menuCache.db and videoCache.db """
        self._menuDb, self._videoDb, self._dbLock = init_dbs(self._g.DATA_PATH, self._g.MarketID)
        self._videodata = SQLiteVideoData(self._videoDb, self._dbLock, self._g.MarketID)
        self._catalog = {}

        try:
            with self._dbLock:
                cur = self._menuDb.execute(
                    'SELECT expiration, catalog_json FROM menu_cache WHERE market_id = ?',
                    (self._g.MarketID,)
                )
                row = cur.fetchone()
            if row is not None:
                exp, raw_json = row
                if time.time() < exp or self._s.freezeCache:
                    self._catalog = json.loads(raw_json, object_pairs_hook=OrderedDict)
        except Exception as exc:
            Log(f'Corrupted catalog cache in menuCache.db: {exc}', Log.WARNING)
            with self._dbLock:
                with self._menuDb:
                    self._menuDb.execute('DELETE FROM menu_cache WHERE market_id = ?', (self._g.MarketID,))
            self._g.dialog.notification('Corrupted catalog cache', 'Unable to load the catalog cache data', xbmcgui.NOTIFICATION_ERROR)

    def _BeautifyText(self, title):
        """ Correct stylistic errors in Amazon's titles """

        for r in self._TextCleanPatterns:
            title = r[0].sub(r[1], title)
        return title

    def _TraverseCatalog(self, path, bRefresh=False):
        """ Extract current node, grandparent node and their names """
        # Fix the unquote_plus problem with unicode_literals by encoding to latin-1 (byte string) and then decoding
        pathList = [unquote_plus(p) for p in path.split(self._separator)]
        for k in range(len(pathList)):
            try:
                pathList[k] = pathList[k].encode('latin-1').decode('utf-8')
            except: pass

        if 0 == len(self._catalog):
            self.BuildRoot()

        # Traverse
        node = self._catalog
        pathLen = len(pathList)
        for i in range(0, pathLen):
            nodeName = pathList[i]

            # Stop one short while refreshing, due to python mutability reasons
            if bRefresh and (i == (pathLen - 1)):
                break

            # Populate children list to avoid favourite/library traversal errors
            if 'children' in node:
                for cid in node['children']:
                    if cid not in node:
                        node[cid] = {}
                    try:
                        if 0 == len(self._videodata[cid]['children']):
                            node[cid]['lazyLoadURL'] = self._videodata[cid]['ref']
                    except: pass

            if nodeName not in node:
                self._g.dialog.notification('Catalog error', 'Catalog path not available…', xbmcgui.NOTIFICATION_ERROR)
                return None, None
            elif ('lazyLoadURL' in node[nodeName]) or ('lazyLoadData' in node[nodeName]):
                self._LazyLoad(node[nodeName], pathList[0:1 + i])
            node = node[nodeName]
        return node, pathList

    def _UpdateProfiles(self, data=None):
        data = GrabJSON(self._g.BaseUrl + '/gp/video/profiles') if data is None else data
        data = data.get('lists', data)
        pr = data.get('cerberus', data.get('profiles'))
        perm = get_key({}, data, 'permissions', 'editAndEnterPermissions')
        if pr is not None:
            profiles = []
            if 'activeProfile' in pr:
                profiles.append(pr['activeProfile'])
            if 'otherProfiles' in pr:
                profiles += pr['otherProfiles']
            if isinstance(pr, list):
                profiles = pr
            self._catalog['profiles'] = {}
            for p in profiles:
                if p.get('isSelected', False):
                    self._catalog['profiles']['active'] = p['id']
                if p.get('isDefault', False):
                    self._catalog['profiles']['default'] = p['id']
                self._catalog['profiles'][p['id']] = {
                    'title': p.get('name', 'Default'),
                    'metadata': {'artmeta': {'thumb': p['avatarUrl']}},
                    'verb': f"pv/profiles/switch/{p['id']}",
                    'endpoint': p['switchLink'],
                }
                if get_key('ALLOWED', perm, p['id'], 'enterPermission', 'action') != 'ALLOWED':
                    challenge = perm[p['id']]['enterPermission']['challenge']
                    self._catalog['profiles'][p['id']]['challenge'] = {
                        'title': challenge['title'],
                        'endpoint': challenge['continueAction']['destructuredUrl']
                    }
            self._Flush()

    def Route(self, verb, path):
        if 'search' == verb:
            self._g.pv.DeleteCache(1)
            self._g.pv.BrowseRoot()
        elif 'browse' == verb: self._g.pv.Browse(path)
        elif 'refresh' == verb: self._g.pv.Refresh(path)
        elif 'profiles' == verb: self._g.pv.Profile(path)
        elif 'languageselect' == verb: self._g.pv.LanguageSelect()
        elif 'clearcache' == verb: self._g.pv.DeleteCache()
        elif 'wltoogle' == verb: self._g.pv.Watchlist(path)
        elif 'ageSettings' == verb: self._g.dialog.ok(self._g.__plugin__, 'Age Restrictions are currently unavailable for WebApi users')
        elif 'sethome' == verb: self._g.pv.SetHome(path)

    def Watchlist(self, path):
        path = path.split(self._separator)
        result = ''
        remove = int(path[-1])
        action = ['Add', 'Remove'][remove]
        u_path = '' if self._g.UsePrimeVideo else '/gp/video'
        gtis = unquote_plus(path[-2]).split(',')
        query = 'metadataToEnrich={"placement":"HOVER","watchlist":"true"}&titleIDsToEnrich=%s&isCleanSlateActive=1&journeyIngressContext=' % json.dumps(gtis).replace(' ', '')
        data = GrabJSON(self._g.BaseUrl + u_path + '/api/enrichItemMetadata?' + quote_plus(query, safe='=&'))
        for enrich in data['enrichments']:
            endp = data['enrichments'][enrich]['watchlistAction']['endpoint']
            endp['query']['tag'] = action
            result = getURL(self._g.BaseUrl + endp['partialURL'], postdata=endp['query'], useCookie=True, check=True)
            if result:
                Log(f"Watchlist: {endp['query']['tag'].lower()} {enrich}")

        if result:
            if remove == 1:
                self.Refresh(self._separator.join(path[:-2]), False)
                xbmc.executebuiltin('Container.Refresh')
            else:
                self.Refresh('root/Watchlist/watchlist', False)

    def Profile(self, path):
        """ Profile actions """
        path = path.split(self._separator)

        def List(home=None):
            """ List all inactive profiles """
            # Hit a fast endpoint to grab and update CSRF tokens
            ul = home is not None
            self._UpdateProfiles(home)
            for k, p in self._catalog['profiles'].items():
                if k in ['active', 'default'] or k == self._catalog['profiles']['active']:
                    continue
                addDir(p['title'], 'True', p['verb'], p['metadata']['artmeta'])
            xbmcplugin.endOfDirectory(self._g.pluginhandle, succeeded=True, cacheToDisc=False, updateListing=ul)

        def Switch():
            """ Switch to an inactive profile """
            # Sometimes the switch just fails due to CSRF, possibly due to problems on Amazon's servers,
            # so we patiently try a few times
            not_selected = path[1] != self._catalog['profiles']['active']
            owner_profile = path[1] == self._catalog['profiles']['default']
            for _ in range(0, 5):
                endpoint = self._catalog['profiles'][path[1]]['endpoint']
                endpoint['query'].update(_Challenge())
                if endpoint['query'].get('pinProof', 'true') == '':
                    return
                # need 2 cycles if account PIN is requested
                for _ in range(2 if owner_profile and endpoint['query'].get('pinProof') else 1):
                    home = GrabJSON(self._g.BaseUrl + endpoint['partialURL'], endpoint['query'])
                    self._UpdateProfiles(home)
                if path[1] == self._catalog['profiles']['active']:
                    break
                sleep(3)

            if path[1] == self._catalog['profiles']['active']:
                if not_selected:
                    self.BuildRoot()
                    List(home)
            else:
                self._g.dialog.notification(self._g.addon.getAddonInfo('name'), 'Profile switching unavailable at the moment, please try again', time=1000, sound=False)

        def _Challenge():
            challenge = self._catalog['profiles'][path[1]].get('challenge')
            if challenge:
                pin = self._g.dialog.numeric(0, challenge['title'], bHiddenInput=self._s.show_pass is False)
                query = challenge['endpoint']['query']
                query['pin'] = pin
                proof = GrabJSON(self._g.BaseUrl + challenge['endpoint']['partialURL'], query)
                if 'pinProof' in proof:
                    return {'pinProof': proof['pinProof']}
            return {}

        if 'list' == path[0]: List()
        elif 'switch' == path[0]: Switch()

    def DeleteCache(self, clear=0):
        """ Pops up a dialog asking cache purge confirmation """
        from .dialogs import PV_ClearCache

        # ClearCache.value returns a boolean bitmask
        if 0 == clear:
            clear = PV_ClearCache().value
        if 0 > clear:
            return

        # Clear catalog (menuCache.db)
        if 1 & clear:
            self._catalog = {}
            if self._menuDb is not None:
                with self._dbLock:
                    with self._menuDb:
                        self._menuDb.execute('DELETE FROM menu_cache WHERE market_id = ?', (self._g.MarketID,))
            Log('Deleting catalog', Log.DEBUG)

        # Clear video data (videoCache.db)
        if 2 & clear:
            if isinstance(self._videodata, SQLiteVideoData):
                self._videodata.clear_market()
            else:
                self._videodata = SQLiteVideoData(self._videoDb, self._dbLock, self._g.MarketID)
            Log('Deleting video data', Log.DEBUG)

        del clear

    def LanguageSelect(self):
        cj = MechanizeLogin()
        loc, lang = LocaleSelector()
        Log(f'Changing text language to [{loc}] {lang}', Log.DEBUG)
        if self._g.UsePrimeVideo:
            cj.set('lc-main-av', loc, path='/')
        else:
            ck = [k for k, v in cj.items() if 'sess-at-' in k][0].replace('sess-at-', 'lc-')
            cj.set(ck, loc, path='/')
        saveUserCookies(cj)
        self.DeleteCache()

    @staticmethod
    def SetHome(path):
        path = unquote_plus(path) if path else 'root'
        writeConfig('home', path)

    def BrowseRoot(self):
        """ Build and load the root PrimeVideo menu """

        if 0 == len(self._catalog):
            ''' Build the root catalog '''
            if not self.BuildRoot():
                exit()
        self.Browse(self._home_path)

    def BuildRoot(self, home=None):
        """ Parse the top menu on primevideo.com and build the root catalog """

        # Specify `None` instead of just not empty to avoid multiple queries to the same endpoint
        if home is None:
            home = GrabJSON(self._g.BaseUrl + ('/storefront' if self._g.UsePrimeVideo else '/gp/video/storefront'))
            if not home:
                return False
            self._UpdateProfiles(home)

        # Profil PIN required
        if home.get('pageType') == 'ATVProfiles' or (len(home) == 2 and 'profiles' in home):
            self.Profile(self._separator.join(['switch', self._catalog['profiles']['active']]))
            return self.BuildRoot()

        self._catalog['root'] = OrderedDict()

        # Insert the watchlist
        navigation = None
        try:
            watchlist = next((x for x in home['yourAccount']['links'] if '/watchlist/' in x['href']), None)
            self._catalog['root']['Watchlist'] = {'title': watchlist['text'], 'lazyLoadURL': FQify(watchlist['href'])}
        except: pass
        try:
            navigation = deepcopy(home['mainMenu']['links'] if 'mainMenu' in home else home['lists']['mainMenuLinks'])
            watchlist = next((x for x in navigation if 'pv-nav-mystuff' in x['id']), None)
            self._catalog['root']['Watchlist'] = {'title': self._BeautifyText(watchlist['text']), 'lazyLoadURL': watchlist['href']}
        except: pass
        try:
            navigation = deepcopy(home['nav']['navigationNodes'])
            watchlist = next((x for x in navigation if 'pv-nav-my-stuff' in x['id']), None)
            self._catalog['root']['Watchlist'] = {'title': self._BeautifyText(watchlist['label'])}
            if watchlist['subMenu'][0].get('subNodes') is None:
                ms = watchlist['url'].rsplit('/', 1)
                data = {'subNodes': [{'id': 'watchlist', 'label': getString(30245), 'url': '/watchlist/'.join(ms)},
                                     {'id': 'library', 'label': getString(30100), 'url': '/library/'.join(ms)}]}
            else:
                data = watchlist['subMenu'][0]
            self._catalog['root']['Watchlist']['lazyLoadData'] = data
        except: pass

        if 'Watchlist' not in self._catalog['root']:
            Log('Watchlist link not found', Log.ERROR)

        # Insert the main sections, in order
        if navigation is not None:
            cn = 0
            while navigation:
                link = navigation.pop(0)
                mml = 'links' in link
                # Skip watchlist and useless stuff
                if link['id'] in ['pv-nav-mystuff', 'pv-nav-my-stuff', 'pv-nav-ad-free','pv-nav-account-and-profiles', 'pv-nav-join-prime']:
                    continue
                if self._g.UsePrimeVideo and mml:
                    navigation = link['links'] + navigation
                    continue
                cn += 1
                title = link.get('text', link.get('label'))
                id = f"coll{cn}_{title + ('_mmlinks' if mml else '')}"
                self._catalog['root'][id] = {'title': self._BeautifyText(title), 'lazyLoadURL': link.get('href', link.get('url'))}
                # Avoid unnecessary calls when loading the current page in the future
                if 'isHighlighted' in link and link['isHighlighted']:
                    self._catalog['root'][id]['lazyLoadData'] = home
                # Adding main menu categories
                if mml:
                    self._catalog['root'][id]['lazyLoadData'] = home
        else:
            self._g.dialog.ok(getString(30278), getString(30279).format(self._g.BaseUrl, ''))
            Log(f'Unable to parse the navigation menu for {self._g.BaseUrl}', Log.ERROR)
            return False

        # Insert the searching mechanism
        try:
            if 'nav' in home:
                sfa = home['nav']['searchBar']['submitSearchDestructuredEndpoint']
                title = home['nav']['searchBar']['searchBarPlaceholderLabel']
            else:
                sfa = home['searchBar']['searchFormAction']
                title = home['searchBar']['searchFormPlaceholder']
            # Build the query parametrization
            query = ''
            if 'query' in sfa:
                query += '&'.join([f'{k}={v}' for k, v in sfa['query'].items()])
            query = query if not query else query + '&'
            self._catalog['root']['Search'] = {
                'title': self._BeautifyText(title),
                'verb': '?mode=Search',
                'endpoint': f"{sfa['partialURL']}?{query}phrase={{}}"
            }
        except:
            self._catalog['root']['Search'] = {
                'title': getString(30108),
                'verb': '?mode=Search',
                'endpoint': '/gp/video/search?phrase={}'
            }

        # Set the expiration based on settings (defaults to 12 hours) and flush to disk
        self._catalog['expiration'] = self._s.catalogCacheExpiry + int(time.time())
        self._Flush()

        return True

    def Browse(self, path, bNoSort=False, export=0):
        """ Display and navigate the menu for PrimeVideo users """

        nodeKeys = []
        maincall = False
        path_sep = path.split(self._separator)
        # export: 1=folder without refresh 2=single file (episode/movie) 3=folder with refresh 4=watchlist 5=watchlist (auto)
        if 'export=' in path_sep[-1]:
            export = int(path_sep[-1].split('=')[1])
            path = '/'.join(path_sep[:-1])
            if export > 9:
                Log('Export started')
                maincall = True
                export -= 10
            if export == 2:
                nodeKeys = [path_sep[-2]]
                nodeName = ''
        if export:
            SetupLibrary()
            writeConfig('exporting', time.time())
        if export == 3:
            self.Refresh(path, busy=False)
        elif export > 3:
            Log('Export of watchlist started')
            self.Browse(path + '/all', export=3)
            if export == 5:
                writeConfig('last_wl_export', time.time())
                xbmc.executebuiltin('UpdateLibrary(video)')
            Log('Export of watchlist finished')
            writeConfig('exporting', '')
            return

        if export == 0 and getConfig('exporting') != '':
            if (float(getConfig('exporting', 0)) + 60) > time.time():
                self._g.dialog.notification(self._g.__plugin__, 'Export process is running, please wait until it is finished')
                return
            else:
                writeConfig('exporting', '')

        # Add multiuser menu if needed
        if self._s.multiuser and (self._home_path == path) and (1 < len(loadUsers())):
            addDir(getString(30134).format(loadUser('name')), '', f'pv/browse/root{self._separator}SwitchUser', cm=self._g.CONTEXTMENU_MULTIUSER)
        if ('root' + self._separator + 'SwitchUser') == path:
            if switchUser():
                self.DeleteCache(1)
                xbmc.executebuiltin('Container.Refresh')
            return

        # Add Profiles
        if self._s.profiles and (self._home_path == path) and ('profiles' in self._catalog):
            activeProfile = self._catalog['profiles'][self._catalog['profiles']['active']]
            addDir(activeProfile['title'], 'True', 'pv/profiles/list', activeProfile['metadata']['artmeta'])

        if 1 > len(nodeKeys):
            node, breadcrumb = self._TraverseCatalog(path)
            if None is node:
                return

            if (self._home_path == path) and path != 'root':
                for n in ['Watchlist', 'Search']:
                    cat = deepcopy(self._catalog['root'][n])
                    node.update({n: cat})

            # Populate children list with empty references
            nodeName = breadcrumb[-1]
            if (nodeName in self._videodata) and ('children' in self._videodata[nodeName]):
                for c in self._videodata[nodeName]['children']:
                    if c not in node:
                        node[c] = {}

            nodeKeys = [k for k in node if k not in ['ref', 'verb', 'title', 'metadata', 'parent', 'siblings', 'children', 'trailer']]
            # Move nextpage entry to end of list
            if 'nextPage' in nodeKeys:
                nodeKeys.pop(nodeKeys.index('nextPage'))
                nodeKeys.append('nextPage')

        # Batch-Preload aller benötigten GTIs (inkl. Kind-/Parent-GTIs) in einer einzigen SQLite-Abfrage
        if isinstance(self._videodata, SQLiteVideoData) and nodeKeys:
            self._videodata.preload(nodeKeys)
            extra_keys = []
            for k in nodeKeys:
                if k in self._videodata:
                    vd_entry = self._videodata[k]
                    extra_keys.extend(vd_entry.get('children', []))
                    if 'parent' in vd_entry:
                        extra_keys.append(vd_entry['parent'])
            if extra_keys:
                self._videodata.preload(extra_keys)

        ft_exp = (2, 0, 1, 3, 0, 2)
        folderType = 0 if 'root' == path else 1
        folderTypeList = []
        for key in nodeKeys:
            entry = deepcopy(self._videodata[key]) if key in self._videodata else node[key]
            title = entry.get('title', nodeName)
            itemPathURI = f"{path if key not in 'Watchlist' else 'root'}{self._separator}{quote_plus(key.encode('utf-8'))}"
            ctxitems = []

            # Squash single season tv shows
            try:
                if 'tvshow' == entry['metadata']['videometa']['mediatype']:
                    if 1 == len(entry['children']):
                        childgti = entry['children'][0]
                        entry = deepcopy(self._videodata[childgti])
                        itemPathURI += f"{self._separator}{quote_plus(childgti.encode('utf-8'))}"
            except: pass

            # Find out if item's a video leaf
            infoLabel = {'title': title}

            try:
                bIsVideo = entry['metadata']['videometa']['mediatype'] in ['episode', 'movie', 'video', 'live', 'event']
            except:
                bIsVideo = False

            # Can we refresh the cache on this/these item(s)?
            bCanRefresh = ('ref' in entry) or ('lazyLoadURL' in entry)
            if ('children' in entry) and (0 < len(entry['children'])):
                bCanRefresh |= (0 < len([k for k in entry['children'] if (k in self._videodata) and ('ref' in self._videodata[k])]))

            if bIsVideo:
                infoLabel['contentType'] = entry['metadata']['videometa']['mediatype']
            elif 'verb' in entry:
                url = entry['verb']
                itemPathURI = ''
            else:
                url = 'pv/browse/' + itemPathURI
            # Log('Encoded PrimeVideo URL: {}'.format(url), Log.DEBUG)

            if bCanRefresh and (0 < len(itemPathURI)):
                # Log('Encoded PrimeVideo refresh URL: pv/refresh/{}'.format(itemPathURI), Log.DEBUG)
                ctxitems.append((getString(30268), f'RunPlugin({self._g.pluginid}pv/refresh/{itemPathURI})'))

            mt = get_key('', entry, 'metadata', 'videometa', 'mediatype')
            # use seasons metadata if missing in epsiodes
            if 'episode' == mt and 'parent' in entry:
                pid = entry['parent']
                for k, v in self._videodata[pid]['metadata']['artmeta'].items():
                    if k not in entry['metadata']['artmeta']:
                        entry['metadata']['artmeta'][k] = v
                for k in ['cast', 'genres', 'director']:
                    if k not in entry['metadata']['videometa'] and k in self._videodata[pid]['metadata']['videometa']:
                        entry['metadata']['videometa'][k] = self._videodata[pid]['metadata']['videometa'][k]
            # In case of tv shows find the oldest season and apply its art
            elif ('tvshow' == mt) and (1 < len(entry.get('children', []))):
                sn = None
                snid = None
                for child in entry['children']:
                    try:
                        childsn = self._videodata[child]['metadata']['videometa']['season']
                        if (None is sn) or (sn > childsn):
                            sn = childsn
                            snid = child
                    except:
                        pass
                if snid:
                    entry['metadata']['artmeta'] = self._videodata[snid]['metadata']['artmeta']
                    entry['metadata']['videometa']['cast'] = self._videodata[snid]['metadata']['videometa'].get('cast', [])
                    entry['metadata']['videometa']['plot'] = '{}\n\n{}'.format(getString(30253).format(len(entry['children'])),
                                                                               self._videodata[snid]['metadata']['videometa'].get('plot',
                                                                                                                                  ''))  # "# series" as plot/description

            folder = True
            if 'metadata' in entry:
                m = entry['metadata']
                if 'artmeta' in m:
                    try:
                        if self._s.pv_episode_thumbnails and ('episode' == m['videometa']['mediatype']):
                            del m['artmeta']['poster']
                    except: pass
                    infoLabel.update(m['artmeta'])
                if 'videometa' in m:
                    # https://codedocs.xyz/xbmc/xbmc/group__python__xbmcgui__listitem.html#ga0b71166869bda87ad744942888fb5f14
                    infoLabel.update(m['videometa'])
                    if bIsVideo:
                        infoLabel['TrailerAvailable'] = entry.get('trailer', False)
                        folder = False
                        if 'runtime' in m:
                            infoLabel['duration'] = m['runtime']
                    try:
                        folderType = {'video': 0, 'movie': 5, 'episode': 4, 'tvshow': 2, 'season': 3, 'live': 0, 'event': 0}[m['videometa']['mediatype']]
                    except:
                        folderType = 2  # Default to category
                    if folderType in [5, 3, 2, 0]:
                        if 'children' in entry:
                            gtis = ','.join(entry['children'])
                        else:
                            gt = entry['metadata']['compactGTI']
                            gtis = self._videodata['urn2gti'].get(gt, gt)
                        in_wl = 1 if path.split('/')[:3] == ['root', 'Watchlist', 'watchlist'] else 0
                        if gtis is not None:
                            mt = self._g.langID.get(m['videometa']['mediatype'])
                            if mt is None:
                                continue
                            if m['videometa']['mediatype'] != 'live':
                                ctxitems.append((getString(30180 + in_wl) % getString(mt), f'RunPlugin({self._g.pluginid}pv/wltoogle/{path}/{quote_plus(gtis)}/{in_wl})'))
                            ctxitems.append((getString(30185) % getString(mt), f'RunPlugin({self._g.pluginid}pv/browse/{itemPathURI}/export={ft_exp[folderType] + 10})'))
                            ctxitems.append((getString(30186), 'UpdateLibrary(video)'))

                if 'schedule' in m:
                    ts = time.time()
                    from datetime import datetime as dt
                    for sh in m['schedule']:
                        us = sh.get('start') / 1000
                        ue = sh.get('end') / 1000
                        if us <= ts <= ue:
                            shm = sh['metadata']
                            infoLabel['plot'] = '{:%H:%M} - {:%H:%M}  {}\n\n{}'.format(dt.fromtimestamp(us), dt.fromtimestamp(ue),
                                                                                       shm.get('title', ''), shm.get('synopsis', ''))
                            if infoLabel['thumb'] is None and 'image' in shm:
                                infoLabel['thumb'] = shm['image'].get('url')

            else:
                if itemPathURI:
                    ctxitems.append((getString(30271), f'RunPlugin({self._g.pluginid}pv/sethome/{quote_plus(itemPathURI)})'))
                if itemPathURI.split(self._separator)[-3:] == ['root', 'Watchlist', 'watchlist']:
                    ctxitems.append((getString(30185) % 'Watchlist', f'RunPlugin({self._g.pluginid}pv/browse/{itemPathURI}/export={4})'))
                    ctxitems.append((getString(30186), 'UpdateLibrary(video)'))

            folderTypeList.append(folderType)
            # If it's a video leaf without an actual video, something went wrong with Amazon servers, just hide it
            if ('nextPage' == key) or (not folder) or (4 > folderType):
                if 4 == folderType and 1 > infoLabel.get('episode', 0):
                    continue
                if export and 4 == folderType and bIsVideo:
                    if 'episode' not in infoLabel or 'season' not in infoLabel or 'tvshowtitle' not in infoLabel or 'trailer' in infoLabel['title']:
                        break
                addVideo(title, key, infoLabel, cm=ctxitems, export=export) if bIsVideo else addDir(title, str(folder), url, infoLabel, cm=ctxitems)
                if export and folder:
                    self.Browse(itemPathURI, export=ft_exp[folderType])

        if not export:
            # Set sort method and view
            # leave folderType if its a single content list or use the most common foldertype for mixed content, except episodes or seasons (it will break sorting)
            folderType = folderType if 2 > len(set(folderTypeList)) else \
            sorted([(folderTypeList.count(x), x) for x in set(folderTypeList) if x not in [3, 4]], reverse=True)[0][1]
            # https://codedocs.xyz/xbmc/xbmc/group__python__xbmcplugin.html#ga85b3bff796fd644fb28f87b136025f40
            xbmcplugin.addSortMethod(self._g.pluginhandle, [
                xbmcplugin.SORT_METHOD_NONE,  # Root
                xbmcplugin.SORT_METHOD_NONE,  # Category list
                xbmcplugin.SORT_METHOD_NONE,  # Category
                xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE,  # TV Show (Seasons list)
                xbmcplugin.SORT_METHOD_EPISODE,  # Season (Episodes list)
                xbmcplugin.SORT_METHOD_NONE,  # Movies list
            ][0 if bNoSort or ('nextPage' in node) else folderType])

            folderType = 0 if 2 > folderType else folderType
            setContentAndView([None, 'videos', 'series', 'season', 'episode', 'movie'][folderType], cacheToDisc=False)
        elif maincall:
            writeConfig('exporting', '')
            Log('Export finished')

    def Search(self, searchString):
        """ Provide search functionality for PrimeVideo """
        self._catalog['search'] = OrderedDict([('lazyLoadURL', self._catalog['root']['Search']['endpoint'].format(searchString))])
        self.Browse('search', True)

    def Refresh(self, path, bRefreshVideodata=True, busy=True):
        """ Provides cache refresh functionality """

        refreshes = []
        node, breadcrumb = self._TraverseCatalog(path, True)
        if None is node:
            return

        # Only refresh if previously loaded. If not loaded, and specifically asked, perform a full (lazy) loading
        k = breadcrumb[-1]
        if (k not in node) and (k in self._videodata):
            node[k] = {}

        if ('lazyLoadURL' in node[k]) or ('lazyLoadData' in node[k]):
            refreshes.append((node[k], breadcrumb, False))
        else:
            bShow = False
            if 'ref' in node[k]:  # ref's in the cache already
                Log(f'Refreshing element in the cache: {k}', Log.DEBUG)
                targetURL = node[k]['ref']
            elif 'ref' in self._videodata[k]:  # Season
                Log(f'Refreshing season: {k}', Log.DEBUG)
                targetURL = self._videodata[k]['ref']
            else:  # TV Show
                Log(f'Refreshing Show: {k}', Log.DEBUG)
                bShow = True
                for season in [l for l in self._videodata[k]['children'] if (l in self._videodata) and ('ref' in self._videodata[l])]:
                    if (season in node[k]) and ('lazyLoadURL' in node[k][season]):
                        bRefresh = False
                    else:
                        bRefresh = bRefreshVideodata
                        node[k][season] = {'lazyLoadURL': self._videodata[season]['ref']}
                    refreshes.append((node[k][season], breadcrumb + [season], bRefresh))

            if not bShow:
                # Reset the basic metadata
                title = node[k]['title'] if 'title' in node[k] else None
                node[k] = {'lazyLoadURL': targetURL}
                if title:
                    node[k]['title'] = title
                refreshes.append((node[k], breadcrumb, bRefreshVideodata))

        from contextlib import contextmanager

        @contextmanager
        def _busy_dialog():
            if busy:
                xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
            try:
                yield
            finally:
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

        with _busy_dialog():
            for r in refreshes:
                Log(f'Refresh params: {r}')
                self._LazyLoad(r[0], r[1], r[2])

    def _LazyLoad(self, obj, breadcrumb=None, bCacheRefresh=False):
        """ Loader and parser of all the PrimeVideo.com queries """

        def MaxSize(imgUrl):
            """ Strip the dynamic resize triggers from the URL (and other effects, such as blur) """
            return re.sub(r'\._.*_\.', '.', imgUrl) if imgUrl is not None else None

        def ExtractURN(url):
            """ Extract the unique resource name identifier """

            ret = self._reURN.search(url)
            return None if not ret else ret.group(1)

        def DelocalizeDate(lang, datestr):
            """ Convert language based timestamps into YYYY-MM-DD """
            if lang not in self._dateParserData or (lang in self._dateParserData and 'deconstruct' not in self._dateParserData[lang]):
                Log(f'Unable to decode date "{datestr}": language "{lang}" not supported', Log.DEBUG)
                return datestr

            # Try to decode the date as localized format
            try:
                p = self._dateParserData[lang]['deconstruct'].search(datestr.lower())
            except: pass
            # Sometimes the date is returned with an american format and/or not localized
            if None is p:
                try:
                    p = self._dateParserData['generic'].search(datestr.lower())
                except: pass
                if (None is p) or ('en_US' == lang):
                    Log(f'Unable to parse date "{datestr}" with language "{lang}": format changed?', Log.DEBUG)
                    return datestr

            # Get rid of the Match object
            p = {'d': p.group('d'), 'm': p.group('m'), 'y': p.group('y')}

            # Convert the month into an integer or die trying
            if p['m'].isdigit():
                p['m'] = int(p['m'])
            else:
                # Since they're inept, try with asiatic numeric months first
                try:
                    p['m'] = int(self._dateParserData['asianMonthExtractor'].match(p['m'])[1])
                except: pass

                def MonthToInt(langCode):
                    # Try the conversion against localized full month name
                    try:
                        p['m'] = self._dateParserData[langCode]['months'][p['m']]
                    except:
                        if 'months' in self._dateParserData[langCode]:
                            # Try to treat the month name as shortened
                            for monthName in self._dateParserData[langCode]['months']:
                                if monthName.startswith(p['m']):
                                    p['m'] = self._dateParserData[langCode]['months'][monthName]
                                    break

                # Delocalize date with the provided locale
                if not isinstance(p['m'], int):
                    MonthToInt(lang)

                # If all else failed, try en_US if applicable
                if (not isinstance(p['m'], int)) and ('en_US' != lang):
                    Log(f'Unable to parse month "{datestr}" with language "{lang}": trying english', Log.DEBUG)
                    MonthToInt('en_US')

                # (╯°□°）╯︵ ┻━┻
                if not isinstance(p['m'], int):
                    Log(f'Unable to parse month "{datestr}" with any known language combination', Log.WARNING)
                    return datestr

            # Reassemble (YYYY-MM-DD)
            return f"{p['y']}-{p['m']:0>2}-{p['d']:0>2}"

        def NotifyUser(msg, bForceDisplay=False):
            """ Pop up messages while scraping to inform users of progress """

            if not hasattr(NotifyUser, 'lastNotification'):
                NotifyUser.lastNotification = 0
            if bForceDisplay or (NotifyUser.lastNotification < time.time()):
                # Only update once every other second, to avoid endless message queue
                NotifyUser.lastNotification = 1 + time.time()
                self._g.dialog.notification(self._g.addon.getAddonInfo('name'), msg, time=1000, sound=False)

        def AddLiveTV(o, item):
            """ Add a direct playable live TV channel to the list """
            chid = item.get('playbackAction', item).get('channelId')
            if 'station' in item and chid is None:
                chid = item['station'].get('id')
            if chid is not None and chid not in o:
                thumb = None
                o[chid] = {'metadata': {'artmeta': {}, 'videometa': {'mediatype': 'live'}}}
                if 'station' in item:
                    title = item['station']['name']
                    o[chid]['metadata']['schedule'] = item['station'].get('schedule', {})
                    thumb = item['station'].get('logo')
                elif 'playbackAction' in item:
                    title = item['playbackAction']['label']
                elif 'facetText' in item:
                    title = item['facetText']
                else:
                    title = item['title']
                if 'image' in item:
                    thumb = item['image'].get('url')
                o[chid]['title'] = title
                o[chid]['metadata']['videometa']['plot'] = title + ('\n\n' + item['synopsis'] if 'synopsis' in item else '')
                o[chid]['metadata']['artmeta']['poster'] = o[chid]['metadata']['artmeta']['thumb'] = MaxSize(thumb)
                o[chid]['metadata']['compactGTI'] = ExtractURN(item['playbackAction']['fallbackUrl']) if 'playbackAction' in item else chid

        def AddLiveEvent(o, item, url):
            urn = ExtractURN(url)
            """ Add a live event to the list """
            if urn in o:
                return
            title = return_value(item, 'title' if 'title' in item else 'heading', 'text')
            liveInfo = item.get('liveInfo', item.get('liveEvent', {}))
            liveStat = liveInfo.get('status', liveInfo.get('liveStateType', '')).lower() == 'live'
            liveTime = liveInfo.get('timeBadge', liveInfo.get('dateTime'))
            o[urn] = {'title': title, 'lazyLoadURL': url,
                      'metadata': {'artmeta': {}, 'videometa': {'mediatype': 'event'}}}
            o[urn]['metadata']['compactGTI'] = ExtractURN(item['playbackAction']['fallbackUrl']) if 'playbackAction' in item else urn
            when = ''
            if liveTime or liveStat:
                when = 'Live' if not liveTime else liveTime
                if 'venue' in liveInfo:
                    when = f"{when} @ {liveInfo['venue']}"
                when += '\n\n'
            o[urn]['metadata']['videometa']['plot'] = when + item.get('synopsis', item.get('text', ''))
            if 'imageSrc' in item:
                o[urn]['metadata']['artmeta']['thumb'] = MaxSize(item['imageSrc'])
            elif 'image' in item and 'url' in item['image']:
                o[urn]['metadata']['artmeta']['thumb'] = MaxSize(item['image']['url'])
            elif key_exists(item, 'packshot', 'image', 'src'):
                o[urn]['metadata']['artmeta']['thumb'] = MaxSize(item['packshot']['image']['src'])
            elif 'images' in item:
                o[urn]['metadata']['artmeta']['thumb'] = MaxSize(findKey('url', item['images']))

        def _fetch_tv_ancestor_show(episode_gti):
            """Ermittelt den übergeordneten Serien-Knoten (SHOW) einer Episode via GetPlaybackResources."""
            try:
                suc, res = getURLData(
                    'catalog/GetPlaybackResources',
                    episode_gti,
                    silent=True,
                    extra=True,
                    useCookie=cj if cj else True,
                    opt='&titleDecorationScheme=primary-content',
                    dRes='CatalogMetadata'
                )
                if suc and isinstance(res, dict):
                    family = res.get('catalogMetadata', {}).get('family', {}).get('tvAncestors', [])
                    for a in family:
                        if a.get('catalog', {}).get('type') == 'SHOW':
                            return a['catalog']
            except Exception:
                pass
            return None

        def _apply_show_parent(seasonGTI, parent_cat):
            """Verknüpft eine Staffel und ihre Siblings deterministisch mit dem Serien-Parent-Knoten."""
            if not parent_cat or seasonGTI not in self._videodata:
                return None, False
            pid = parent_cat['id']
            self._videodata[seasonGTI]['parent'] = pid
            if pid not in self._videodata:
                self._videodata[pid] = {
                    'title': parent_cat['title'],
                    'metadata': {'videometa': {'mediatype': 'tvshow'}},
                    'children': [seasonGTI]
                }
            else:
                if 'children' not in self._videodata[pid]:
                    self._videodata[pid]['children'] = []
                if seasonGTI not in self._videodata[pid]['children']:
                    self._videodata[pid]['children'].append(seasonGTI)
            for gti in self._videodata[seasonGTI].get('siblings', []):
                if gti in self._videodata:
                    self._videodata[gti]['parent'] = pid
                if gti not in self._videodata[pid]['children']:
                    self._videodata[pid]['children'].append(gti)
            return pid, True

        def AddSeason(oid, o, bCacheRefresh, url, preloaded_data=None, pending_ancestors=None):
            """ Given a season, adds TV Shows to the catalog """
            urn = ExtractURN(url)
            parent = None
            season = {}
            bUpdatedVideoData = False
            if bCacheRefresh or (urn not in self._videodata['urn2gti']):
                # Find the show the season belongs to
                url += ('' if 'episodeListSize' in url else ('&' if '?' in url else '?') + 'episodeListSize=9999')
                bUpdatedVideoData |= ParseSinglePage(oid, season, bCacheRefresh, data=preloaded_data, url=url)
                seasonGTI = self._videodata['urn2gti'].get(urn)
                if seasonGTI and seasonGTI in self._videodata:
                    children = self._videodata[seasonGTI].get('children', [])
                    if children:
                        if pending_ancestors is not None:
                            pending_ancestors.append((oid, o, season, seasonGTI, children[0]))
                            return bUpdatedVideoData
                        parent_cat = _fetch_tv_ancestor_show(children[0])
                        if parent_cat:
                            parent, upd = _apply_show_parent(seasonGTI, parent_cat)
                            bUpdatedVideoData |= upd
            else:
                parent = self._videodata[self._videodata['urn2gti'][urn]].get('parent')
            bSeasonOnly = (not parent) or (oid == parent)
            if not bSeasonOnly:
                o[parent] = deepcopy(self._videodata[parent])
                o = o[parent]
            for sid in season:
                o[sid] = season[sid]
            return bUpdatedVideoData

        def ParseSinglePage(oid, o, bCacheRefresh, data=None, url=None):
            """ Parse PrimeVideo.com single movie/season pages.
                `url` is discarded in favour of `data`, if present.
            """
            urn = ExtractURN(url)
            # Load from cache, if available
            if (not bCacheRefresh) and (urn in self._videodata['urn2gti']) and (self._videodata['urn2gti'][urn] in self._videodata):
                gti = self._videodata['urn2gti'][urn]
                vd = self._videodata[gti]
                # Movie
                if 'children' not in vd:
                    if gti not in o:
                        o[gti] = vd
                    return False

                # TV Series
                bEpisodesOnly = oid == gti
                siblings = [] if bEpisodesOnly else vd['siblings'][:]
                siblings.append(gti)
                if isinstance(self._videodata, SQLiteVideoData):
                    self._videodata.preload(siblings)
                siblings = sorted(siblings, key=(lambda k: get_key(0, self._videodata.get(k, {}), 'metadata', 'videometa', 'season')))
                for gti in siblings:
                    # Add season if we're not inside a season already
                    if (not bEpisodesOnly) and (gti not in o):
                        o[gti] = deepcopy(self._videodata[gti])
                        dest = o[gti]
                    else:
                        o = deepcopy(self._videodata[gti])
                        dest = o
                    # Add cached episodes
                    for c in dest['children']:
                        if c not in dest:
                            dest[c] = {}
                return False

            if url:
                url = FQify(url)
            if not data:
                if not url:
                    return False
                data = GrabJSON(url)
                if not data:
                    NotifyUser(getString(30256), True)
                    Log(f'Unable to fetch the url: {url}', Log.ERROR)
                    return False

            # convert widgets field to state
            if 'widgets' in data and 'episodeList' in data['widgets']:
                season_id = urn = data['widgets']['pageContext']['pageTitleId']
                data['state'] = {'episodeList': {'actions': data['widgets']['episodeList']['actions'], 'cardTitleIds': []},
                                 'pageTitleId': season_id,
                                 'detail': {season_id: {'titleType': 'season'}}, 'self': {season_id: {'titleType': 'season'}}}
                for episodes in data['widgets']['episodeList']['episodes']:
                    data['state']['episodeList']['cardTitleIds'].append(episodes['titleID'])
                    for state_key in ['detail', 'self']:
                        data['state'][state_key].update({episodes['titleID']: episodes[state_key]})

            # Video/season/movie data are in the `state` field of the response
            if 'state' not in data:
                return False

            state = data['state']  # Video info
            title_id = state['pageTitleId']
            GTIs = []  # List of inserted GTIs
            parents = {}  # Map of parents
            bUpdated = False  # Video data updated

            # seasons are now only in state['seasons'] so add them to state['self']
            if 'seasons' in state:
                for k, v in state['seasons'].items():
                    for d in v:
                        gti = d['seasonId']
                        if gti not in state['self']:
                            lnk = d['seasonLink']
                            cgti = ExtractURN(lnk)
                            state['self'][gti] = d
                            state['self'][gti].update({'compactGTI': cgti, 'asins': [cgti], 'link': lnk, 'titleType': 'season', 'gti': gti, })
                del state['seasons']

            if ('self' in state) and (oid not in state['self']):
                res = [x for x in state['self'] if oid in (state['self'][x].get('compactGTI' if self._g.UsePrimeVideo else 'asins') or '')]
                if len(res) > 1:
                    oid = res[0]

            # Find out if it's a live event. Custom parsing rules apply
            if ('self' in state) and (oid in state['self']) and ('event' == state['self'][oid]['titleType'].lower()):
                # List of video streams
                items = [oid]
                for i in state['collections'][oid]:
                    if i['collectionType'] not in ['schedule', 'highlights']:
                        continue
                    for id in i['titleIds']:
                        if id not in items:
                            items.append(id)
                items = {v: i for i, v in enumerate(items)}

                details = state['detail']
                if 'detail' in details:
                    details = details['detail']
                if 'headerDetail' in state['detail']:
                    details.update(state['detail']['headerDetail'])
                    del state['detail']['headerDetail']
                if 'btfMoreDetails' in state['detail']:
                    del state['detail']['btfMoreDetails']

                # Add video streams in order
                for vid, i in sorted(details.items(), key=lambda t: 9999 if t[0] not in items else items[t[0]]):
                    if (vid in o) or (vid not in items):
                        continue
                    if vid in state['buyboxTitleId']:
                        vid = state['buyboxTitleId'][vid]
                        if vid in o:
                            continue

                    o[vid] = {'title': i['title'], 'metadata': {'compactGTI': i.get('compactGTI', i.get('catalogId', vid)),
                                                                'artmeta': {}, 'videometa': {'mediatype': 'video'}}}

                    if 'liveState' in i:
                        try:
                            mats = state['action']['atf'][oid]['playbackActions']['main']['children']
                            mats = [a['videoMaterialType'].lower() for a in mats if vid == a['playbackID']]
                            if 'live' in mats:
                                o[vid]['metadata']['videometa']['mediatype'] = 'live'
                        except: pass

                    # Date and synopsis as a unified synopsis
                    synopsis = None if 'synopsis' not in i else i['synopsis']
                    datetime = None if 'pageDateTimeBadge' not in i else i['pageDateTimeBadge']
                    if not datetime:
                        datetime = datetime if 'dateTimeBadge' not in i else i['dateTimeBadge']
                    if datetime:
                        synopsis = ('{0}\n{1}' if synopsis else '{0}').format(datetime, synopsis)
                    if synopsis:
                        o[vid]['metadata']['videometa']['plot'] = synopsis

                    # Images
                    if 'images' in i:
                        for k, v in {'thumb': 'packshot', 'poster': 'covershot', 'fanart': 'heroshot'}.items():
                            if v in i['images']:
                                o[vid]['metadata']['artmeta'][k] = i['images'][v]

                return False

            # Seasons (episodes are now listed in self too)
            # Only add seasons if we are not inside a season already
            if ('self' in state) and (oid not in state['self']) and ('widgets' not in data):
                # "self": {"amzn1.dv.gti.[…]": {"gti": "amzn1.dv.gti.[…]", "link": "/detail/[…]"}}
                for gti in [k for k in state['self'] if 'season' == state['self'][k]['titleType'].lower()]:
                    s = state['self'][gti]
                    gti = s['gti'] if self._g.UsePrimeVideo else gti
                    if gti not in self._videodata:
                        self._videodata[gti] = {'ref': s['link'], 'children': [], 'siblings': []}
                        bUpdated = True
                    else:
                        # Season might be initialized with raw data first, make sure to add the necessary basics
                        for k, v in {'ref': s['link'], 'children': [], 'siblings': []}.items():
                            if k not in self._videodata[gti]:
                                self._videodata[gti][k] = v
                                bUpdated = True
                        o[gti] = deepcopy(self._videodata[gti])
                    GTIs.append(gti)
                    siblings = [k for k, ss in state['self'].items() if k != gti and ss['titleType'].lower() == s['titleType'].lower()]
                    if siblings != self._videodata[gti]['siblings']:
                        self._videodata[gti]['siblings'] = siblings
                        bUpdated = True
                    if 'sequenceNumber' in s:
                        try:
                            self._videodata[gti]['title'] = data['strings']['AVOD_DP_season_selector'].format(seasonNumber=s['sequenceNumber'])
                        except:
                            self._videodata[gti]['title'] = f"{getString(30167)} {s['sequenceNumber']}"

            # Episodes lists
            episodes = state.get('collections', {})
            if 'episodeList' in state:
                episodes = {title_id: [state['episodeList']]}
                if ('self' in state and title_id in state['self']) and ('actions' in state['episodeList'] and 'pagination' in state['episodeList']['actions']):
                    for next_epi in state['episodeList']['actions']['pagination']:
                        if next_epi['tokenType'].lower() == 'nextpage':
                            next_url = f"/gp/video/api/getDetailWidgets?titleID={title_id}&isTvodOnRow=&widgets=%5B%7B%22widgetType%22%3A%22EpisodeList%22%2C%22widgetToken%22%3A%22{quote(quote(next_epi['token']))}%22%7D%5D"
                            requestURLs.append(next_url)
            # "collections": {"amzn1.dv.gti.[…]": [{"titleIds": ["amzn1.dv.gti.[…]", "amzn1.dv.gti.[…]"]}]}
            # "collections": {"amzn1.dv.gti.[…]": [{"cardTitleIds": ["amzn1.dv.gti.[…]", "amzn1.dv.gti.[…]"]}]}
            # "episodeList": {"cardTitleIds": ["amzn1.dv.gti.[…]", "amzn1.dv.gti.[…]"]}
            for gti, lc in episodes.items():
                for le in lc:
                    for e in le.get('titleIds', le.get('cardTitleIds', [])):
                        GTIs.append(e)
                        # Save parent/children relationships
                        parents[e] = gti
                        if gti in self._videodata and e not in self._videodata[gti]['children']:
                            self._videodata[gti]['children'].append(e)
                            bUpdated = True

            # Video info
            if 'detail' not in state:
                return bUpdated

            if urn not in self._videodata['urn2gti']:
                self._videodata['urn2gti'][urn] = title_id

            # Both of these versions have been spotted in the wild
            # { "detail": { "headerDetail": {…}, "amzn1.dv.gti.[…]": {…} }
            # { "detail": { "detail": { "amzn1.dv.gti.[…]": {…} }, "headerDetail": {…} } }
            details = state['detail']
            if 'detail' in details:
                details = details['detail']
            # headerDetail contains sometimes gtis/asins, which are not included in details
            if 'headerDetail' in state['detail']:
                details.update(state['detail']['headerDetail'])
                del state['detail']['headerDetail']
            if 'btfMoreDetails' in state['detail']:
                del state['detail']['btfMoreDetails']

            # Get details, seasons first
            # WARNING: seasons may not have proper initialization at this stage
            for gti in sorted(details, key=lambda x: 'season' != details[x]['titleType'].lower()):
                # not inside a season/show: (oid not in details)
                #     not already appended: (gti not in GTIs)
                # part of the page details: ('self' in state) & (gti in state['self'])
                if details[gti]['titleType'].lower() == 'collection':
                    continue
                if details[gti]['titleType'].lower() == 'season' and 'widgets' in data:
                    continue
                if (oid not in details) and (gti not in GTIs) and ('self' in state) and (gti in state['self']):
                    GTIs.append(gti)
                    o[gti] = {}
                if gti not in self._videodata:
                    self._videodata[gti] = {}
                vd = self._videodata[gti]

                # Meta prep
                if 'metadata' not in vd:
                    vd['metadata'] = {'compactGTI': urn, 'artmeta': {}, 'videometa': {}}
                    bUpdated = True
                if 'artmeta' not in vd['metadata']:
                    vd['metadata']['artmeta'] = {}
                    bUpdated = True
                if 'videometa' not in vd['metadata']:
                    vd['metadata']['videometa'] = {}
                    bUpdated = True

                # Parent
                if gti in parents:
                    vd['parent'] = parents[gti]
                    bUpdated = True

                item = details[gti]  # Shortcut
                titleType = item.get('titleType', '').lower()

                # add missing episodes infos from season or self.gti
                if titleType == 'episode' and 'episodeNumber' not in item:
                    seasonDetails = details[title_id]
                    if gti in state['self']:
                        item['episodeNumber'] = state['self'][gti].get('sequenceNumber', 0)
                    for titleinfo in ['amazonRating', 'contributors', 'genres', 'ratingBadge', 'studios', 'seasonNumber']:
                        if titleinfo not in item and titleinfo in seasonDetails:
                            item[titleinfo] = seasonDetails[titleinfo]

                # Title
                if bCacheRefresh or ('title' not in vd):
                    if titleType == 'season' and 'seasonNumber' in item:
                        try:
                            vd['title'] = data['strings']['AVOD_DP_season_selector'].format(seasonNumber=item['seasonNumber'])
                        except:
                            vd['title'] = f"{getString(30167)} {item['seasonNumber']}"
                    else:
                        vd['title'] = self._BeautifyText(item['title'])
                    bUpdated = True

                # Images
                for k, v in {'thumb': 'packshot', 'poster': 'titleshot', 'fanart': 'heroshot'}.items():
                    if (bCacheRefresh or (k not in vd['metadata']['artmeta'])) and \
                       ('images' in item) and (v in item['images']) and item['images'][v]:
                        vd['metadata']['artmeta'][k] = item['images'][v]
                        bUpdated = True

                # Mediatype
                if bCacheRefresh or ('mediatype' not in vd['metadata']['videometa']):
                    vd['metadata']['videometa']['mediatype'] = titleType
                    bUpdated = True

                # Synopsis, media type, year, duration
                for k, v in {'plot': 'synopsis', 'year': 'releaseYear', 'duration': 'duration'}.items():
                    if (bCacheRefresh or (k not in vd['metadata']['videometa'])) and (v in item):
                        vd['metadata']['videometa'][k] = item[v]
                        bUpdated = True

                # Genres
                if (bCacheRefresh or ('genre' not in vd['metadata']['videometa'])) and ('genres' in item) and item['genres']:
                    vd['metadata']['videometa']['genre'] = [g['text'] for g in item['genres']]
                    bUpdated = True

                # Premiered/Aired
                if (bCacheRefresh or ('premiered' not in vd['metadata']['videometa'])) and ('releaseDate' in item) and item['releaseDate']:
                    vd['metadata']['videometa']['premiered'] = DelocalizeDate(amzLang, item['releaseDate'])
                    vd['metadata']['videometa']['aired'] = vd['metadata']['videometa']['premiered']
                    bUpdated = True

                # MPAA
                if (bCacheRefresh or ('mpaa' not in vd['metadata']['videometa'])) and \
                   ('ratingBadge' in item) and ('displayText' in item['ratingBadge']) and item['ratingBadge']['displayText']:
                    vd['metadata']['videometa']['mpaa'] = item['ratingBadge']['displayText']
                    bUpdated = True

                # Contributors (`producers` are ignored)
                if 'contributors' in item:
                    for k, v in OrderedDict([('directors', 'director'), ('starringActors', 'cast'), ('supportingActors', 'cast'), ('cast', 'cast')]).items():
                        if k in item['contributors']:
                            for p in item['contributors'][k]:
                                if 'name' in p:
                                    try:
                                        if p['name'] not in vd['metadata']['videometa'][v]:
                                            vd['metadata']['videometa'][v].append(p['name'])
                                    except KeyError:
                                        vd['metadata']['videometa'][v] = [p['name']]
                                    bUpdated = True

                # Season, TV show title
                if ('seasonNumber' in item) and item['seasonNumber']:
                    if bCacheRefresh or ('season' not in vd['metadata']['videometa']):
                        vd['metadata']['videometa']['season'] = item['seasonNumber']
                        bUpdated = True
                    if bCacheRefresh or ('tvshowtitle' not in vd['metadata']['videometa']):
                        try:
                            vd['metadata']['videometa']['tvshowtitle'] = item['parentTitle']
                            bUpdated = True
                        except: pass

                # Episode, Season, TV show title
                if ('episodeNumber' in item) and item['episodeNumber']:
                    if bCacheRefresh or ('episode' not in vd['metadata']['videometa']):
                        vd['metadata']['videometa']['episode'] = item['episodeNumber']
                        bUpdated = True
                    if bCacheRefresh or ('season' not in vd['metadata']['videometa']):
                        try:
                            vd['metadata']['videometa']['season'] = self._videodata[vd['parent']]['metadata']['videometa']['season']
                            bUpdated = True
                        except: pass
                    if bCacheRefresh or ('tvshowtitle' not in vd['metadata']['videometa']):
                        try:
                            vd['metadata']['videometa']['tvshowtitle'] = self._videodata[vd['parent']]['metadata']['videometa']['tvshowtitle']
                            bUpdated = True
                        except: pass

            # IMDB ratings — "imdb": {"amzn1.dv.gti.[…]": {"score": 8.5}}
            if ('imdb' in state) and state['imdb']:
                for gti in state['imdb']:
                    vmd = self._videodata[gti]['metadata']['videometa']
                    if (bCacheRefresh or ('rating' not in vmd)) and ('score' in state['imdb'][gti]) and state['imdb'][gti]['score']:
                        vmd['rating'] = state['imdb'][gti]['score']
                        bUpdated = True

            # Trailer — "trailer": {"amzn1.dv.gti.[…]": {"playbackID": "amzn1.dv.gti.[…]", "playbackURL": "/detail/[ShortGTI]/ref=atv_dp_watch_trailer?autoplay=trailer"}}
            if ('trailer' in state) and state['trailer']:
                for gti in state['trailer']:
                    if 'trailer' not in self._videodata[gti]:
                        self._videodata[gti]['trailer'] = True
                        bUpdated = True

            return bUpdated

        if ('lazyLoadURL' not in obj) and ('lazyLoadData' not in obj):
            return
        requestURLs = [obj['lazyLoadURL'] if 'lazyLoadURL' in obj else None]

        from urllib.parse import urlencode
        # Find the locale set in the cookies
        amzLang = None
        cj = MechanizeLogin()
        if cj:
            if self._g.UsePrimeVideo:
                amzLang = cj.get('lc-main-av', path='/')
            else:
                # after first language change lc-acb(de/uk) cookie gets stored
                cval = [v for k, v in cj.items() if 'lc-acb' in k]
                if cval:
                    amzLang = cval[0]
                else:
                    i18 = {'EUR': 'de_DE', 'GBP': 'en_GB', 'JPY': 'ja_JP', 'USD': 'en_US'}
                    pref = cj.get('i18n-prefs', path='/')
                    if pref:
                        amzLang = i18.get(pref)

        amzLang = amzLang if amzLang else 'en_US'

        bUpdatedVideoData = False  # Whether or not the pvData has been updated
        pageNumber = 1  # Page number

        while 0 < len(requestURLs):
            # Stufe: Wenn mehrere Folge-URLs (z.B. Episoden-Paginierung oder Siblings) in der Queue liegen,
            # rufen wir den aktuellen Batch parallel über GrabJSONParallel ab.
            batch_urls = []
            while requestURLs and len(batch_urls) < 4:
                u = requestURLs.pop(0)
                if u is not None:
                    u += ('' if 'episodeListSize' in u or '/api/' in u else ('&' if '?' in u else '?') + 'episodeListSize=9999')
                batch_urls.append(u)

            prefetched_batch = {}
            urls_to_grab = [
                u for u in batch_urls
                if u is not None and 'lazyLoadData' not in obj and (
                    bCacheRefresh or not ExtractURN(u) or ExtractURN(u) not in self._videodata['urn2gti']
                )
            ]
            if len(urls_to_grab) > 1:
                prefetched_batch = GrabJSONParallel(urls_to_grab, max_workers=4)

            for requestURL in batch_urls:
                o = obj

                # Load content
                bCouldNotParse = False
                try:
                    cnt = None

                    # Use cached data, if available
                    if 'lazyLoadData' in o:
                        cnt = o['lazyLoadData']
                        del o['lazyLoadData']

                    # Load content from an external url
                    if not cnt:
                        urn = ExtractURN(requestURL)
                        if (not bCacheRefresh) and urn and (urn in self._videodata['urn2gti']):
                            # There are no API endpoints for movie/series pages, so we handle them in a separate function
                            with self._dbLock:
                                bUpdatedVideoData |= ParseSinglePage(breadcrumb[-1], o, bCacheRefresh, url=requestURL)
                                if 'lazyLoadURL' in o:
                                    if 'ref' not in o:
                                        o['ref'] = o['lazyLoadURL']
                                    del o['lazyLoadURL']
                            continue
                        else:
                            cnt = prefetched_batch.get(requestURL) if requestURL in prefetched_batch else GrabJSON(requestURL)

                    # Don't switch direct action for reference until we have content to show for it
                    if cnt and ('lazyLoadURL' in o):
                        if 'ref' not in o:
                            o['ref'] = o['lazyLoadURL']
                        del o['lazyLoadURL']
                except:
                    bCouldNotParse = True
                if bCouldNotParse or (not cnt):
                    self._g.dialog.notification(getString(30251), (requestURL or '')[:48], xbmcgui.NOTIFICATION_ERROR)
                    Log(f'Unable to fetch the url: {requestURL}', Log.ERROR)
                    continue

            # Submenus
            mmpos = [len(breadcrumb)-i for i, x in enumerate(breadcrumb) if 'mmlinks' in x]
            if len(mmpos) > 0 and (mmpos[0] == 1 or (mmpos[0] == 2 and 'genres' in breadcrumb[-1])):
                catid = ''
                for link in cnt['lists']['mainMenuLinks']:
                    for lk in link.get('links', []):
                        if 'heading' in lk.get('features', ''):
                            catid = lk['id']
                            if mmpos[0] == 1 and 'genres' in catid:
                                o[lk['id']] = \
                                    {'title': self._BeautifyText(lk['text']), 'lazyLoadURL': lk['href'], 'lazyLoadData': cnt}
                            continue
                        if (mmpos[0] == 2 and catid in breadcrumb[-1]) or (mmpos[0] == 1 and 'categories' in catid):
                            o[lk['id']] = {'title': self._BeautifyText(lk['text']), 'lazyLoadURL': lk['href']}
                cnt = ''
            # Categories
            elif 'collections' in cnt or 'containers' in cnt:
                var = 'collection' if len(cnt.get('collections', [])) > 0 else 'container'
                filtered_col = [x for x in cnt[var + 's'] if x[var + 'Type'].lower() not in ['chartscarousel', 'standardhero', 'textcontainer', 'superhero', 'tentpolehero']]
                if len(filtered_col) > 1:
                    for collection in filtered_col:
                        if 'text' in collection or 'title' in collection:
                            facet = True
                            txt = collection.get('text', '').strip()
                            if txt == '' and 'title' in collection:
                                txt = collection['title'].strip()
                            facetxt = collection.get('facet', {}).get('alternateText')
                            facetxt = collection.get('facetText') if facetxt is None else facetxt
                            entcues = collection.get('entitlementCues', {})
                            isprime = collection.get('offerClassification', '') == 'PRIME' or entcues.get('offerType') in ['SVOD', 'TVOD']
                            isincl = entcues.get('entitledCarousel', 'Entitled') == 'Entitled'
                            if facetxt is None:
                                facet = False
                                facetxt = txt
                            if isprime:
                                facetxt = f'[COLOR {self._s.primecol}]{facetxt}[/COLOR]'
                            if not isincl:
                                facetxt = f'[COLOR {self._s.paycol}]{facetxt}[/COLOR]'
                            txt = f"{facetxt}{' ' if isprime or isincl is False else ': '}{txt}" if facet else txt  # facetxt doesn't mark correctly / to colorful
                            id = txt
                            o[id] = {'title': self._BeautifyText(txt)}
                            if 'seeMoreLink' in collection:
                                o[id]['lazyLoadURL'] = collection['seeMoreLink']['url']
                            elif 'paginationTargetId' in collection:
                                q = ['{}={}'.format(k.replace('paginationServiceToken', 'serviceToken').replace('paginationStartIndex', 'startIndex'),
                                                    ','.join(v) if isinstance(v, list) else quote_plus(str(v)))
                                     for k, v in collection.items() if k in ['collectionType', 'paginationServiceToken', 'paginationTargetId', 'tags', 'paginationStartIndex']]
                                q.append('pageId=live' if 'EpgGroup' in collection.get('containerType', '') else 'pageId=home')
                                q.append('pageSize=20&pageType=home')
                                q.append('isCleanSlateActive=1&isDiscoverActive=1&isLivePageActive=1&variant=desktopWindows&payloadScheme=default&actionScheme=default'
                                         '&decorationScheme=web-decoration-asin-v4&featureScheme=web-features-v6&widgetScheme=web-explorecs-v11&dynamicFeatures=integration'
                                         '&dynamicFeatures=CLIENT_DECORATION_ENABLE_DAAPI&dynamicFeatures=ENABLE_DRAPER_CONTENT&dynamicFeatures=HorizontalPagination'
                                         '&dynamicFeatures=CleanSlate&dynamicFeatures=EpgContainerPagination&dynamicFeatures=ENABLE_GPCI&dynamicFeatures=SupportsImageTextLinkTextInStandardHero')
                                if 'collectionType' not in q:
                                    q.append('collectionType=Container')
                                if var == 'collection':
                                    q.append('facetType=' + collection['facet']['facetType'])
                                o[id]['lazyLoadData'] = collection
                                o[id]['lazyLoadData']['paginationTargetUrl'] = '/gp/video/api/paginateCollection?' + '&'.join(q)
                            else:
                                o[id]['lazyLoadData'] = collection
                        elif 'items' in collection:
                            # LiveTV
                            for item in collection['items']:
                                AddLiveTV(o, item)
                elif len(filtered_col) == 1:
                    cnt = filtered_col[0]
            # MyStuff
            wl_lib = 'legacy-' + breadcrumb[2] if ['root', 'Watchlist'] == breadcrumb[:2] and len(breadcrumb) > 2 and not breadcrumb[2].startswith('ms_') else ''
            vo = ''
            if ['root', 'Watchlist'] == breadcrumb:
                if 'subNodes' in cnt:
                    for f in cnt['subNodes']:
                        id = f['id'].replace('pv-nav-my-stuff-', '').lower()
                        if 'all' not in id:
                            o[id] = {'title': f['label'], 'lazyLoadURL': f['url']}
                elif 'viewOutput' in cnt:
                    wl = return_item(cnt, 'viewOutput', 'features', 'view-filter')
                    for f in wl['filters']:
                        o[f['viewType']] = {'title': f['text'], 'lazyLoadURL': f['apiUrl' if 'apiUrl' in f else 'href']}
                        if f.get('active', False):
                            o[f['viewType']]['lazyLoadData'] = cnt
                else:
                    for f in cnt['content']['baseOutput']['containers']:
                        o[f'ms_{len(o)}'] = {'title': f['text'], 'lazyLoadURL': f['seeMoreLink']['url']}
            # MyStuff categories
            elif len(wl_lib) > 0 and len(breadcrumb) == 3:
                if 'viewOutput' in cnt:
                    wl = return_item(cnt, 'viewOutput', 'features', wl_lib)
                else:
                    wl = {'filters': x['values'] for x in return_item(cnt, 'content', 'baseOutput', 'filters', 'items') if isinstance(x, dict) and 'OFFER_FILTER' in x['id']}
                for f in wl.get('filters', []):
                    id = f['id'].lower()
                    url = f.get('apiUrl', f.get('href'))
                    url = ('/' + id + '/').join(requestURL.rsplit('/', 1)) if url is None else url
                    o[id] = {'title': f['text'], 'lazyLoadURL': url}
                    if f.get('applied') or f.get('isCurrentlyApplied'):
                        o[id]['lazyLoadData'] = cnt
            else:
                vo = cnt['results'] if 'results' in cnt else return_item(cnt, 'viewOutput', 'features', wl_lib, 'content')
                vo = return_item(vo, 'content', 'baseOutput', 'containers')
                if isinstance(vo, list):
                    vo = vo[0]
                items = vo.get('entities', []) + vo.get('items', []) + vo.get('content', {}).get('items', [])

                # Stufe 1 (Paralleler Prefetch der Katalog-Elemente):
                # Sammle alle Ziel-URLs (Filme & Serien/Staffeln), die noch nicht im SQLite-Cache liegen,
                # und lade sie in einer parallelen Welle über GrabJSONParallel vorab.
                parsed_items = []
                urls_to_prefetch = []
                for item in items:
                    tile = return_value(item, 'image', 'alternateText')
                    tile_cov = item.get('image', {})
                    if isinstance(tile, dict):
                        if item.get('widgetType', '').lower() == 'imagetextlink':
                            tile = item.get('title', item.get('displayTitle', item.get('alternateText')))
                            tile_cov = item.get('images', {})
                        else:
                            tile = None
                    if 'heading' in item or 'title' in item or tile:
                        try:
                            iu = item['href'] if 'href' in item else item['link' if 'link' in item else 'title']['url']
                        except:
                            iu = None
                        try:
                            wl = 'watchlistAction' if 'watchlistAction' in item else 'watchlistButton'
                            t = item[wl]['endpoint']['query']['titleType'].lower()
                        except:
                            t = ''
                        is_season_or_show = (t in ['season', 'show']) or ('season' in item) or ('show' in item)
                        fetch_url = iu
                        if iu and not ('station' in item or (tile and iu) or ('liveInfo' in item) or ('event' == t)):
                            urn = ExtractURN(iu)
                            if is_season_or_show:
                                fetch_url = iu + ('' if 'episodeListSize' in iu else ('&' if '?' in iu else '?') + 'episodeListSize=9999')
                            if bCacheRefresh or (urn and urn not in self._videodata['urn2gti']):
                                urls_to_prefetch.append(fetch_url)
                        parsed_items.append((item, tile, tile_cov, iu, fetch_url, t, is_season_or_show))

                prefetched_pages = GrabJSONParallel(urls_to_prefetch, max_workers=4) if urls_to_prefetch else {}
                pending_ancestors = []

                with self._dbLock:
                    for item, tile, tile_cov, iu, fetch_url, t, is_season_or_show in parsed_items:
                        if 'station' in item:
                            AddLiveTV(o, item)
                        elif tile and iu:
                            id = f'tile_{len(o)}'
                            o[id] = {'title': tile, 'lazyLoadURL': iu, 'metadata': {'artmeta': {'thumb': findKey('url', tile_cov)}}}
                        elif ('liveInfo' in item) or ('event' == t):
                            AddLiveEvent(o, item, iu)
                        elif not is_season_or_show:
                            bUpdatedVideoData |= ParseSinglePage(
                                breadcrumb[-1], o, bCacheRefresh,
                                data=prefetched_pages.get(fetch_url), url=iu
                            )
                        else:
                            bUpdatedVideoData |= AddSeason(
                                breadcrumb[-1], o, bCacheRefresh, iu,
                                preloaded_data=prefetched_pages.get(fetch_url),
                                pending_ancestors=pending_ancestors
                            )

                # Stufe 2 (Serien-Hierarchie & tvAncestors parallel auflösen):
                if pending_ancestors:
                    ep_gtis = list(dict.fromkeys(pa[4] for pa in pending_ancestors if pa[4]))
                    ancestor_map = {}
                    if len(ep_gtis) == 1:
                        ancestor_map[ep_gtis[0]] = _fetch_tv_ancestor_show(ep_gtis[0])
                    elif len(ep_gtis) > 1:
                        with ThreadPoolExecutor(max_workers=min(4, len(ep_gtis))) as executor:
                            fut_map = {executor.submit(_fetch_tv_ancestor_show, ep): ep for ep in ep_gtis}
                            for fut in as_completed(fut_map):
                                ep = fut_map[fut]
                                if self._g.monitor.abortRequested():
                                    break
                                try:
                                    ancestor_map[ep] = fut.result()
                                except Exception:
                                    ancestor_map[ep] = None

                    with self._dbLock:
                        for oid_pa, o_pa, season_pa, seasonGTI_pa, ep_gti_pa in pending_ancestors:
                            parent_cat = ancestor_map.get(ep_gti_pa)
                            parent_id = None
                            if parent_cat:
                                parent_id, upd = _apply_show_parent(seasonGTI_pa, parent_cat)
                                bUpdatedVideoData |= upd
                            bSeasonOnly = (not parent_id) or (oid_pa == parent_id)
                            target_o = o_pa
                            if not bSeasonOnly:
                                target_o[parent_id] = deepcopy(self._videodata[parent_id])
                                target_o = target_o[parent_id]
                            for sid in season_pa:
                                target_o[sid] = season_pa[sid]


                # Single page
                bSinglePage = False
                if 'state' in cnt or 'widgets' in cnt:
                    bSinglePage = True
                    with self._dbLock:
                        bUpdatedVideoData |= ParseSinglePage(breadcrumb[-1], o, bCacheRefresh, data=cnt, url=requestURL)
                # Pagination
                if ('pagination' in cnt) or (key_exists(cnt, 'viewOutput', 'features', wl_lib, 'content', 'seeMoreHref'))\
                        or ('hasMoreItems' in cnt) or ('paginationTargetId' in vo):
                    nextPage = None
                    if 'viewOutput' in cnt:
                        # Dynamic AJAX pagination
                        seeMore = cnt['viewOutput']['features'][wl_lib]['content']
                        if seeMore['nextPageStartIndex'] < seeMore['totalItems']:
                            nextPage = seeMore['seeMoreHref']
                    elif 'pagination' in cnt:
                        if 'paginator' in cnt['pagination']:
                            nextPage = next((x['href'] for x in cnt['pagination']['paginator'] if
                                             (('type' in x) and ('NextPage' == x['type'])) or
                                             (('*className*' in x) and ('atv.wps.PaginatorNext' == x['*className*'])) or
                                             (('__type' in x) and ('PaginatorNext' in x['__type']))), None)
                        elif 'queryParameters' in cnt['pagination']:
                            q = cnt['pagination']['queryParameters']
                            q = {k.replace('content', 'page') if k in ['contentId', 'contentType'] else k: v for k, v in q.items()}
                            q.update({'isCleanSlateActive': '1', 'isDiscoverActive': '1', 'isLivePageActive': '1', 'variant': 'desktopWindows',
                                      'payloadScheme': 'default'})

                            if 'vpage' in decode_token(q['serviceToken']):
                                nextPage = '/gp/video/api/getLandingPage?' + urlencode(q, doseq=True)
                            else:
                                q = {k.replace('targetId', 'paginationTargetId') if k in 'targetId' else k: v for k, v in q.items()}
                                q.update({'collectionType': 'Container'} if 'collectionType' not in q else {})
                                nextPage = '/gp/video/api/paginateCollection?' + urlencode(q, doseq=True)
                    elif cnt.get('hasMoreItems', False) and 'startIndex=' in requestURL:
                        idx = int(re.search(r'startIndex=(\d*)', requestURL).group(1))
                        nextPage = requestURL.replace(f'startIndex={idx}', f'startIndex={idx + 20}')
                    elif 'paginationTargetUrl' in vo:
                        nextPage = vo['paginationTargetUrl']
                    elif 'paginationTargetId' in vo:
                        q = ['{}={}'.format(k.replace('paginationServiceToken', 'serviceToken').replace('paginationStartIndex', 'startIndex'),
                                            ','.join(v) if isinstance(v, list) else quote_plus(str(v)))
                             for k, v in vo.items() if k in ['collectionType', 'paginationServiceToken', 'paginationTargetId', 'tags', 'paginationStartIndex']]
                        q.append('pageSize=20&pageType=browse&pageId=default&variant=desktopWindows&actionScheme=default&payloadScheme=default'
                                 '&decorationScheme=web-search-decoration-tournaments-v2&featureScheme=web-search-v4&dynamicFeatures=HorizontalPagination&widgetScheme=web-explorecs-v11')
                        if 'collectionType' not in q:
                            q.append('collectionType=Container')
                        nextPage = '/gp/video/api/paginateCollection?' + '&'.join(q)

                    if nextPage:
                        # Determine if we can auto page
                        p = self._s.pagination
                        bAutoPaginate = True
                        preloadPages = 2 if (p['all'] or p['collections']) else 10
                        # Always autoload episode list
                        if bSinglePage:
                            pass
                        # Auto pagination if not disabled for Search and Watchlist
                        elif 'search' == breadcrumb[0]:  # /search/*
                            bAutoPaginate = not (p['all'] or p['search'])
                        elif 'Watchlist' == breadcrumb[1]:  # /root/watchlist/*
                            bAutoPaginate = not (p['all'] or p['watchlist'])
                        # Always auto load category lists for pv, on tld load only 10 pages at most, then paginate if appropriate
                        elif (2 < len(breadcrumb) and (p['all'] or p['collections'])) if self._g.UsePrimeVideo else pageNumber >= preloadPages:
                            bAutoPaginate = False

                        if bAutoPaginate:
                            requestURLs.append(nextPage)
                        else:
                            # Insert pagination folder
                            o['nextPage'] = {'title': getString(30267), 'lazyLoadURL': nextPage, 'metadata': {'artmeta': {'thumb': self._g.NextIcon}}}

            # Notify new page
            if 0 < len(requestURLs):
                if (0 == (pageNumber % 5)) and bUpdatedVideoData:
                    self._Flush(bFlushCacheData=False, bFlushVideoData=True)
                    bUpdatedVideoData = False
                pageNumber += 1
                NotifyUser(getString(30252).format(pageNumber))

        # Flush catalog and data
        self._Flush(bFlushVideoData=bCacheRefresh or bUpdatedVideoData)
