from slyguy.constants import REPO_DOMAIN

## NEWS ##
NEWS_URL = REPO_DOMAIN+'/.repo/news.json.gz'
ADDONS_URL = REPO_DOMAIN+'/.repo/addons.json.gz'
ADDONS_MD5 = REPO_DOMAIN+'/.repo/addons.json.md5'
NEWS_CHECK_TIME = 3600 #60mins
UPDATES_CHECK_TIME = 1800 #30mins
