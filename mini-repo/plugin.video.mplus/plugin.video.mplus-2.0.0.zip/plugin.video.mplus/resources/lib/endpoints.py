# encoding: utf-8
#
# SPDX-License-Identifier: LGPL-2.1-or-later

from __future__ import unicode_literals, absolute_import, division

endpoints = {
    "account_info": "https://soter-pf.sve.video.telefonicaservices.com/service/login/{deviceType}/accountInfo?legacy=true",
    "activacion_dispositivo_cuenta_tk": "https://soter-pf.sve.video.telefonicaservices.com/service/login/devices?deviceType={deviceType}&accountId={ACCOUNTNUMBER}&legacy=true",
    "autenticacion_tk": "https://auth.dof6.com/movistarplus/api/devices/{deviceType}/users/authenticate",
    "avatares": "https://ottcache.dof6.com/vod/config/perfiles/config/avatares5.json",
    "borradofavoritos": "https://grmovistar.imagenio.telefonica.net/asfe/rest/users/favorites/{family}/{contentId}",
    "borrargrabacionindividual": "https://grmovistar.imagenio.telefonica.net/asfe/rest/users/npvrRecordings/{showId}",
    "buscar_best": "https://perso.dof6.com/movistarplus/{deviceType}/users/contents/search?accountnumber={ACCOUNTNUMBER}&profile={profile}&term={texto}&mode=VODRU7D&showSeries=series&distilledTvRights={distilledTvRights}&version=8.1&mdrm={mdrm}&tlsstream=true&demarcation={demarcation}",
    "canales_old": "https://ottcache.dof6.com/movistarplus/{deviceType}/{profile}/contents/channels?mdrm={mdrm}&tlsstream=true&demarcation={demarcation}&version=8.1",
    "canales": "https://soteroc-pf.cdn.sve.video.telefonicaservices.com/service/contents/{deviceType}/{profile}/contents/channels?mdrm={mdrm}&tlsstream=true&demarcation={demarcation}&v=10&startover=U7D",
    "cerrarsesiondispositivo": "https://clientservices.dof6.com/movistarplus/accounts/{ACCOUNTNUMBER}/devices/{DEVICEID}/sessions?qspVersion=ssp",
    "consultar": "https://ottcache.dof6.com/movistarplus/{deviceType}/contents/browse?profile={profile}&sort={sort}&version=8.1&start={start}&end={end}&mdrm={mdrm}&tlsstream=true&demarcation={demarcation}",
    "eliminardipositivo": "https://clientservices.dof6.com/movistarplus/accounts/{ACCOUNTNUMBER}/devices/{DEVICEID}?qspVersion=ssp",
    "favoritos": "https://soter-pf.sve.video.telefonicaservices.com/service/favorites/{deviceType}/accounts/{accountId}/profiles/{profileId}/favorites?demarcation={demarcation}&v=8.1",
    "ficha": "https://ottcache.dof6.com/movistarplus/{deviceType}/contents/{id}/details?profile={profile}&mediaType={mediatype}&version=8.1&mode={mode}&catalog={catalog}&channels={channels}&state={state}&mdrm={mdrm}&tlsstream=true&demarcation={demarcation}",
    "grabaciones": "https://soter-pf.sve.video.telefonicaservices.com/service/recordings/{deviceType}/accounts/{accountId}/profiles/{profileId}/recordings?start={start}&end={end}&mediaType=FOTOH&demarcation={demarcation}&v=8.1&legacy=true",
    "grabarprograma": "https://grmovistar.imagenio.telefonica.net/asfe/rest/users/npvrRecordings",
    "grabartemporada": "https://grmovistar.imagenio.telefonica.net/asfe/rest/users/npvrScheduledSeasons",
    "initdata": "https://soter-pf.sve.video.telefonicaservices.com/service/login/initData?legacy=true",
    "listaperfiles": "https://soter-pf.sve.video.telefonicaservices.com/service/profile/profiles?excludeForKids=true",
    "marcadofavoritos2": "https://grmovistar.imagenio.telefonica.net/asfe/rest/users/favorites/{family}",
    "nombrardispositivo": "https://clientservices.dof6.com/movistarplus/accounts/{ACCOUNTNUMBER}/devices/{DEVICEID}/name?qspVersion=ssp",
    "obtenerdipositivos": "https://clientservices.dof6.com/movistarplus/accounts/{ACCOUNTNUMBER}/devices?qspVersion=ssp",
    "reactivacion_dispositivo_cuenta_tk": "https://soter-pf.sve.video.telefonicaservices.com/service/login/devices?deviceId={DEVICEID}&deviceType={deviceType}&accountId={ACCOUNTNUMBER}&legacy=true",
    "rejilla": "https://ottcache.dof6.com/movistarplus/{deviceType}/{profile}/epg?from={UTCDATETIME}&span={DURATION}&channel={CHANNELS}&network={NETWORK}&version=8.1&mdrm={mdrm}&tlsstream=true&demarcation={demarcation}",
    "renovacion_cdntoken2_old": "https://idserver.dof6.com/{ACCOUNTNUMBER}/devices/{deviceType}/cdn/token/refresh",
    "renovacion_cdntoken2": "https://soter-pf.sve.video.telefonicaservices.com/service/tcdnidserver/{ACCOUNTNUMBER}/devices/{deviceType}/cdn/token/refresh",
    "renovacion_hztoken": "https://clientservices.dof6.com/movistarplus/{deviceType}/mediaPlayers/{DEVICEID}/hz-token",
    "renovacion_ssptoken": "https://soter-pf.sve.video.telefonicaservices.com/service/login/{deviceType}/accounts/{accountNumber}/ssp-token?mediaPlayerId={mediaPlayerId}",
    "setUpStream": "https://soter-pf.sve.video.telefonicaservices.com/service/session/{deviceType}/{accountId}/session",
    "tearDownStream": "https://soter-pf.sve.video.telefonicaservices.com/service/session/{deviceType}/{accountId}/session/{sessionId}",
    "token": "https://soter-pf.sve.video.telefonicaservices.com/service/oidc/connect/token?deviceClass={deviceType}",
    "ultimasreproducciones": "https://soter-pf.sve.video.telefonicaservices.com/service/series/{deviceType}/accounts/{accountId}/profiles/{profileId}/contents/watching?mode=global&profile={PROFILE}&start={start}&end={end}&container=trackedseries&demarcation={demarcation}",
    "watermarks": "https://ottcache.dof6.com/movistarplus/{deviceType}/channels/{uid}/watermarks?profile={profile}&mdrm=true"
}
