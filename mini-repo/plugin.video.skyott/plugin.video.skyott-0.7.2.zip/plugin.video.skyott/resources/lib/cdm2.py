# encoding: utf-8
#
# SPDX-License-Identifier: LGPL-2.1-or-later

import requests
import json
import re
import base64
from .user_agent import chrome_user_agent
from .log import LOG

user_agent = chrome_user_agent
session = requests.Session()

def get_pssh_from_manifest(url):
  headers = {'User-Agent': user_agent}
  response = session.get(url, headers=headers)
  content = response.content.decode('utf-8')
  pattern = r'<ContentProtection schemeIdUri="urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed">\s*<cenc:pssh.*?>(.*?)</cenc:pssh>'
  pssh = re.search(pattern, content, re.DOTALL)
  if pssh:
    return pssh.group(1)
  return None

def get_pssh_key(pssh, license_url, platform_id=None):
  headers = {'Origin': 'http://108.181.133.95:8080', 'Referer': 'http://108.181.133.95:8080/', 'user-agent': user_agent}

  api_url = "http://108.181.133.95:8080/api"
  build_info = "google/sdk_gphone_x86/generic_x86:8.1.0/OSM1.180201.037/6739391:userdebug/dev-keys"
  #build_info = "xiaomi/whyred/whyred:9/PKQ1.180904.001/V10.3.1.0.PEIMIXM:user/release-keys"
  data = {"license": license_url, "pssh": pssh, "buildInfo": build_info, "cache": False}

  response = session.post(api_url, headers=headers, json=data)
  LOG(response.content)
  if response.status_code != 200:
    return ''

  data = response.json()
  LOG(data)

  keys = data.get('keys')
  LOG('keys: {}'.format(keys))

  res = []
  for key in keys:
    res.append(key['key'])

  return ",".join(res)


def get_cdm_keys(manifest_url, license_url, platform_id=None):
  pssh = get_pssh_from_manifest(manifest_url)
  LOG('pssh: {}'.format(pssh))
  d = {}
  if pssh:
    try:
      key = get_pssh_key(pssh, license_url, platform_id)
      d['key'] = key
    except Exception as e:
      d['error'] = str(e)
  else:
    d['error'] = 'pssh not found'
  return d
